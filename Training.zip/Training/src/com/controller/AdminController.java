package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.bean.Admin;
import com.bean.Employee;
import com.connectionDao.AdminDao;

/**
 * Servlet implementation class AdminController
 */
@WebServlet("/AdminController")
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private AdminDao admDao;

	@Resource(name="gameDB")
	private DataSource dataSource;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminController() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    @Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		admDao=new AdminDao(dataSource);
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		String cmd=request.getParameter("cmd");
		if(cmd.equals("UPDATE")){
			updateEmployee(request,response);
		}
		else if(cmd.equals("DELETE")){
			deleteEmployee(request,response);
		}
		else if(cmd.equals("admChange")){
			changePass(request,response);
		}
		else if(cmd.equals("oldPA")){
			adminPassCheck(request,response);
		}
		
	}

	private void changePass(HttpServletRequest request, HttpServletResponse response) {
		
		String msg="";
		HttpSession session = request.getSession(false);
		String emp_email=(String)session.getAttribute("uname");
		String newPass=request.getParameter("newpass1");
		Admin admin=new Admin(emp_email,newPass);
		
		try {
			PrintWriter pw= response.getWriter();
			msg=admDao.changePass(admin);
			if(msg.equals("notChanged")){
				request.setAttribute("changeErr","Password not changed");
				RequestDispatcher dispatcher= request.getRequestDispatcher("admin_changepass.jsp");
				dispatcher.forward(request, response);
			}
			else if(msg.equals("changed")){
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Password Changed. Login with New Password');");
				pw.println("location='index.jsp';");
				pw.println("</script>");
			}				
				
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private void adminPassCheck(HttpServletRequest request, HttpServletResponse response) {
		
		int result=0;
		Admin admObj=new Admin();
		HttpSession session = request.getSession(false);
		String emp_email=(String)session.getAttribute("uname");
		admObj.setPassword(request.getParameter("pass"));
		admObj.setEmp_email(emp_email);
		try {
			
			PrintWriter pw=response.getWriter();
			result=admDao.passwordCheck(admObj);
			if(result == -1){
				pw.println("Wrong Password");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private void deleteEmployee(HttpServletRequest request, HttpServletResponse response) {
		
		String bensyl_Id=(request.getParameter("curID")).toUpperCase();
		
		String msg="";
		try {
			PrintWriter pw=response.getWriter();
			msg=admDao.deleteEmployeeDetail(bensyl_Id);
			System.out.println(msg);
			if(msg.equals("updated")){
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Employee Deleted');");
				pw.println("location='admin_searchEmp.jsp';");
				pw.println("</script>");
			}
			else if(msg.equals("failed")){
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Deletion Failed');");
				pw.println("location='admin_searchEmp.jsp';");
				pw.println("</script>");
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void updateEmployee(HttpServletRequest request, HttpServletResponse response) {
		
		String msg="";
		String bensyl_Id=(request.getParameter("curID")).toUpperCase();
		Employee objEmp=new Employee();
		objEmp.setBensyl_id((request.getParameter("Bensylid")).toUpperCase());
		objEmp.setEmp_name(request.getParameter("name"));
		objEmp.setEmp_email(request.getParameter("email"));
		objEmp.setLinemng_id(request.getParameter("manager"));
		try {
			
			PrintWriter pw=response.getWriter();
			msg=admDao.updateEmployeeDetail(bensyl_Id,objEmp);
			if(msg.equals("exist")){
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Changed Bensyl ID already exist');");
				pw.println("location='admin_searchEmp.jsp';");
				pw.println("</script>");
			}
			else if(msg.equals("updated")){
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Details Updated Successsfully');");
				pw.println("location='admin_searchEmp.jsp';");
				pw.println("</script>");
			}
			else if(msg.equals("failed")){
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Update Failed');");
				pw.println("location='admin_searchEmp.jsp';");
				pw.println("</script>");
			}
			else{
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
