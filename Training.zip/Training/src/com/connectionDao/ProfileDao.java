package com.connectionDao;

import java.sql.*;
import java.util.*;

import javax.sql.DataSource;

import com.bean.MyProfile;
import com.bean.ScoreBoard;

public class ProfileDao {
	private DataSource dataSource;

	public ProfileDao(DataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}

	public List<MyProfile> getMyProfile(String emp_Id) throws SQLException {
		String sql="";
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		List<MyProfile> trnList=new ArrayList<MyProfile>();
				
		try {
			con=dataSource.getConnection();
			sql="select p.tn_type,t.trn_name,t.trainer,t.training_hour,t.trn_date from "+
					"jithu_emp_training e join jithu_training_detail t on e.trn_det_id=t.trn_det_id "+
					"join jithu_training_types p on t.tn_id=p.tn_id where e.emp_id=?";
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, emp_Id);
			rs=pstmt.executeQuery();
			while(rs.next()){
				MyProfile objProfile=new MyProfile();
				objProfile.setTn_Type(rs.getString("tn_type"));
				objProfile.setTrn_Name(rs.getString("trn_name"));
				objProfile.setTraining_Hour(rs.getFloat("training_hour"));
				objProfile.setTrainer(rs.getString("trainer"));
				objProfile.setTrn_Date(rs.getString("trn_date"));
				trnList.add(objProfile);
			}		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			con.close();
			pstmt.close();
			rs.close();
		}
		return trnList;
	}

	public ScoreBoard getScore(String emp_Id) throws SQLException {
		
		String sql="";
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		ScoreBoard objScore=new ScoreBoard();
		
		try {
			
			con=dataSource.getConnection();
			sql="select hours,score,trn_level,badge,trophy from jithu_scoreboard where emp_id=?";
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, emp_Id);
			rs=pstmt.executeQuery();
			if(rs.next()){
				objScore.setHours(rs.getFloat("hours"));
				objScore.setScore(rs.getFloat("score"));
				objScore.setTrn_level(rs.getInt("trn_level"));
				objScore.setBadge(rs.getInt("badge"));
				objScore.setTrophy(rs.getInt("trophy"));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			con.close();
			pstmt.close();
			if(rs!=null){
				rs.close();				
			}
		}
		return objScore;
	} 
	
	
}
