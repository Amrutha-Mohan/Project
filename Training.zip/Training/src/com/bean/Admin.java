package com.bean;

public class Admin {

	private String emp_email;
	private String password;
	
	public Admin() {
		super();
	}
	
	public Admin(String emp_email, String password) {
		super();
		this.emp_email = emp_email;
		this.password = password;
	}
	
	public String getEmp_email() {
		return emp_email;
	}
	
	public void setEmp_email(String emp_email) {
		this.emp_email = emp_email;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}

}
