package com.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.bean.LogIn;
import com.connectionDao.CredentialDao;

/**
 * Servlet implementation class CredentialController
 */
@WebServlet("/CredentialController")
public class CredentialController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private CredentialDao crdDao;

	@Resource(name="gameDB")
	private DataSource dataSource;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CredentialController() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    @Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		crdDao=new CredentialDao(dataSource);
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
		String cmd=request.getParameter("cmd");
		if(cmd.equals("logout")){
			logout(request,response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		String cmd=request.getParameter("cmd");
		if(cmd.equals("login")){
			login(request,response);
		}
	}

	

	private void login(HttpServletRequest request, HttpServletResponse response) {
		
		LogIn objLog=new LogIn();
		objLog.setUname(request.getParameter("uname"));
		objLog.setPass(request.getParameter("pass"));
		String[] msg=new String[2];
		
		try {
			
			HttpSession session = request.getSession(true);
			msg=crdDao.login(objLog);
			if(msg[0].equals("admin")){
				session.setAttribute("uname", request.getParameter("uname"));
				session.setAttribute("EmpName", msg[1]);
				response.sendRedirect("admin_home.jsp");
			}
			else if(msg[0].equals("employee")){
				session.setAttribute("uname", request.getParameter("uname"));
				session.setAttribute("EmpName", msg[1]);
				response.sendRedirect("user_home.jsp");
			}
			else if(msg[0].equals("invalid")){
				request.setAttribute("ErrLogin","UserName or Password Incorrect");
				RequestDispatcher dispatcher= request.getRequestDispatcher("index.jsp");
				dispatcher.forward(request, response);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void logout(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession session = request.getSession(false);
		if(session!=null){
			session.invalidate();
			try {
				response.sendRedirect("index.jsp");
			}  catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}

}
