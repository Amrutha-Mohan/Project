package com.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;

import javax.sql.DataSource;

public class NewDao {
	private DataSource dataSource;
	
	public NewDao(DataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}

	public void createScoreBoard() {

		System.out.println("Inside calculating scoreboard");
		Connection con=null;
		PreparedStatement pstmt=null, pstmt2=null, pstmt3=null;
		ResultSet rs=null, rs3=null;
		int trn_level=0, badge=0, trophy=0;

		Date date=new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int year = cal.get(Calendar.YEAR);

		String bensyl_id="";
		String sql="select bensyl_id from jithu_employee"; 
		String sql2="update jithu_scoreboard set hours=?,trn_level=?,badge=?,trophy=? where trn_year=? and bensyl_id=?";
		String sql3="select training_hour from jithu_training_detail where bensyl_id=?";

		try{
			con=dataSource.getConnection();
			int result=0;
			float TotHour;
			pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				TotHour=0.0f;
				trn_level=0;
				badge=0;
				trophy=0;
				bensyl_id=rs.getString("bensyl_id");
				pstmt3=con.prepareStatement(sql3);
				pstmt3.setString(1, bensyl_id);
				rs3=pstmt3.executeQuery();
				while(rs3.next())
				{
					TotHour=(TotHour+(rs3.getFloat("training_hour")));
				}
				if(TotHour>=40){
					badge=1;					
				}
				if(TotHour<40){
					trn_level=0;
				}
				else if(TotHour>=40 && TotHour<150){
					trn_level=1;
				}
				else if(TotHour>=150 && TotHour<300){
					trn_level=2;
				}
				else if(TotHour>=300 && TotHour<500){
					trn_level=3;
				}
				else if(TotHour>=500){
					trophy=1;
					trn_level=4;
					int val=(int) (TotHour-500);
					val=val/250;
					badge+=val;
				}

				pstmt2=con.prepareStatement(sql2);
				pstmt2.setFloat(1, TotHour);
				pstmt2.setInt(2,trn_level);
				pstmt2.setInt(3,badge);
				pstmt2.setInt(4,trophy);
				pstmt2.setInt(5,year);
				pstmt2.setString(6,bensyl_id);
				result=pstmt2.executeUpdate();
			}

		}
		catch(NullPointerException e)
		{
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				con.close();
				if(pstmt!=null){
					pstmt.close();
				}
				if(pstmt2!=null){
					pstmt2.close();
				}
				if(pstmt3!=null){
					pstmt2.close();
				}
				if(rs!=null){
					rs.close();
				}
				if(rs3!=null){
					rs3.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
