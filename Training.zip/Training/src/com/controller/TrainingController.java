package com.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.bean.TrainingTypes;
import com.connectionDao.TrainingDao;

/**
 * Servlet implementation class TrainingController
 */
@WebServlet("/TrainingController")
public class TrainingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private TrainingDao trnUtil;

	@Resource(name="gameDB")
	private DataSource dataSource;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TrainingController() {
        super();
    }
    
    @Override
	public void init() throws ServletException {
		super.init();
		trnUtil=new TrainingDao(dataSource);
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		/*HttpSession session = request.getSession(false);
		String uname = (String) session.getAttribute("uname");
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Cache-Control", "no-store");
		response.setDateHeader("Expires", 0);
		response.setHeader("Pragma", "no-cache");
		if (null == uname) {
			request.setAttribute("Error", "Session has ended. Please login again.");
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		}*/
		
		response.setContentType("text/html");

		String cmd=request.getParameter("cmd");
		if(cmd.equals("update")){
			updateTraining(request,response);
		}
		else if(cmd.equals("delete")){
			deleteTraining(request,response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		/*HttpSession session = request.getSession(false);
		String uname = (String) session.getAttribute("uname");
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Cache-Control", "no-store");
		response.setDateHeader("Expires", 0);
		response.setHeader("Pragma", "no-cache");
		if (null == uname) {
			request.setAttribute("Error", "Session has ended. Please login again.");
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		}*/
		
		response.setContentType("text/html");

		String cmd=request.getParameter("cmd");
		if(cmd.equals("training")){
			addTraining(request,response);
		}else if(cmd.equals("trnUpdate")){
			updateTrainingDetails(request,response);
		}

	}

	private void updateTrainingDetails(HttpServletRequest request, HttpServletResponse response) {
		TrainingTypes objTraining=new TrainingTypes();
		objTraining.setTn_id(Integer.parseInt(request.getParameter("tn_id")));
		objTraining.setTn_type(request.getParameter("type"));
		objTraining.setTn_weightage(Float.parseFloat(request.getParameter("weightage")));
		trnUtil.updateTrainingDetails(response,objTraining);
	}

	private void deleteTraining(HttpServletRequest request, HttpServletResponse response) {
		TrainingTypes objTraining=new TrainingTypes();
		objTraining.setTn_id(Integer.parseInt(request.getParameter("tn_id")));
		trnUtil.deleteTrainingDetail(response,objTraining);
	}

	private void updateTraining(HttpServletRequest request, HttpServletResponse response) {
		TrainingTypes objTraining=new TrainingTypes();
		objTraining.setTn_id(Integer.parseInt(request.getParameter("tn_id")));
		objTraining.setTn_type(request.getParameter("tn_type"));
		objTraining.setTn_weightage(Float.parseFloat(request.getParameter("tn_weightage")));
		
		request.setAttribute("trnObj",objTraining);
		RequestDispatcher dispatcher=request.getRequestDispatcher("admin_training_update.jsp");
		try {
			dispatcher.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	private void addTraining(HttpServletRequest request, HttpServletResponse response) {
		TrainingTypes objTraining=new TrainingTypes();
		objTraining.setTn_type(request.getParameter("type"));
		objTraining.setTn_weightage(Float.parseFloat(request.getParameter("weightage")));
		try {
			trnUtil.addTrainingDetail(response,objTraining);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
