package com.connectUtil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBConnection {
	
	private static String driverPath="oracle.jdbc.driver.OracleDriver";
	private static String url="jdbc:oracle:thin:@sla18326:1521:ukahp1d";
	private static String uname="AZT_TRN";
	private static String pword="Azt_trn1#";
	private static Connection con=null;
	private static ResultSet rs=null;
	private static int result=0;
	
	public static Connection init(){
		try {
			Class.forName(driverPath);
			con=DriverManager.getConnection(url, uname, pword);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	
	/*public static ResultSet query(String sql){
		Connection con=init();
		PreparedStatment pstmt=con.prepareStatement(sql);
		
	}*/
}
