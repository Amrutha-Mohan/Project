package com.score;

import java.sql.*;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/EmployeeDetail")
public class EmployeeDetail {
	
	@GET
	@Produces(MediaType.TEXT_XML)
	@Path("{bensyl_id}")
	public String sayHelloXML( @PathParam("bensyl_id") String bensyl_id){
		
		Float hours=0.0f;
		int level=0,badge=0,trophy=0;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@sla18326:1521:ukahp1d", "AZT_TRN", "Azt_trn1#");
			String query="select * from jithu_scoreboard where bensyl_id=?";  
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, bensyl_id);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				hours=rs.getFloat("hours");
				level=rs.getInt("trn_level");
				badge=rs.getInt("badge");
				trophy=rs.getInt("trophy");
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String result="<?xml version='1.0'?>"+
				"<score>"+
				"<hours>"+hours+"</hours>"+
				"<level>"+level+"</level>"+
				"<badge>"+badge+"</badge>"+
				"<trophy>"+trophy+"</trophy>"+
				"</score>";
		return result;
	}
	
	/*@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("{bensyl_id}")
	public String sayHelloXML( @PathParam("bensyl_id") String bensyl_id){
		
		Float hours=0.0f;
		int level=0,badge=0,trophy=0;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@sla18326:1521:ukahp1d", "AZT_TRN", "Azt_trn1#");
			String query="select * from jithu_scoreboard where bensyl_id=?";  
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, bensyl_id);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				hours=rs.getFloat("hours");
				level=rs.getInt("trn_level");
				badge=rs.getInt("badge");
				trophy=rs.getInt("trophy");
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String result=hours+" "+level+" "+badge+" "+trophy;
		return result;
	}*/
	
}
