 $(document).ready(function(){
	   $("#login").click(function(){
           $.ajax({
               url: 'http://localhost:8080/Gamification/Profile?id=i81291',
   success:function(data){
   	alert("testing");
  
                   setTimeout(function() {
                       if(location == 1){
                           $("#carGif").addClass("carAnimate1");
                           setTimeout(function() {
                               $("#tbox1").fadeIn('300');
                               $("#tbox1").append("test");
                           }, 2100);
                       }
                       else if(location == 2){
                           $("#carGif").addClass("carAnimate2");
                           setTimeout(function() {
                               $("#tbox2").fadeIn('300');
                           }, 4100);
                       }
                       else if(location == 3){
                           $("#carGif").addClass("carAnimate3");
                           //$("#note3").slideLeft( "slow" );
                           setTimeout(function() {
                               $("#tbox3").fadeIn('300');
                           }, 5100);
                           /*$("#carGif").animate({
                               bottom: "52%",
                               left: "43%"
                           }, 5000, 'linear', function() {
                               // Animation complete.
                           });*/
                       }
                       else if(location == 4){
                           $("#carGif").addClass("carAnimate4");
                           setTimeout(function() {
                               $("#tbox4").fadeIn('300');
                           }, 7100);
                       }
                   }, 1000);
       
        }
           }
           });
     
        });

    