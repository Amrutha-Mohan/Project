package com.bean;

public class Scores {
	
	private String emp_id;
	private String name;
	private float hours;
	private float score;
	private int trn_level;
	private int badge;
	private int trophy;
	
	public Scores() {
		super();
	}
	
	public Scores(String emp_id, String name, float hours, float score, int trn_level, int badge, int trophy) {
		super();
		this.emp_id = emp_id;
		this.name = name;
		this.hours = hours;
		this.score = score;
		this.trn_level = trn_level;
		this.badge = badge;
		this.trophy = trophy;
	}
	
	public String getEmp_id() {
		return emp_id;
	}
	
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public float getHours() {
		return hours;
	}
	
	public void setHours(float hours) {
		this.hours = hours;
	}
	
	public float getScore() {
		return score;
	}
	
	public void setScore(float score) {
		this.score = score;
	}
	
	public int getTrn_level() {
		return trn_level;
	}
	
	public void setTrn_level(int trn_level) {
		this.trn_level = trn_level;
	}
	
	public int getBadge() {
		return badge;
	}
	
	public void setBadge(int badge) {
		this.badge = badge;
	}
	
	public int getTrophy() {
		return trophy;
	}
	
	public void setTrophy(int trophy) {
		this.trophy = trophy;
	}	
}
