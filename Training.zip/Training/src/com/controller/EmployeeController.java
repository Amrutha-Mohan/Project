package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.bean.Employee;
import com.bean.Manager;
import com.bean.OES;
import com.connectionDao.EmployeeDao;

/**
 * Servlet implementation class EmployeeController
 */
@WebServlet("/EmployeeController")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private EmployeeDao empUtil;

	@Resource(name="gameDB")
	private DataSource dataSource;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeController() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    @Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		empUtil=new EmployeeDao(dataSource);
	}



	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String cmd=request.getParameter("cmd");
		if(cmd.equals("AddEmp")){
			addEmp(request,response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
		/*HttpSession session = request.getSession(false);
		String uname = (String) session.getAttribute("uname");
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Cache-Control", "no-store");
		response.setDateHeader("Expires", 0);
		response.setHeader("Pragma", "no-cache");
		if (null == uname) {
			request.setAttribute("Error", "Session has ended. Please login again.");
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		}*/
		
		String cmd=request.getParameter("cmd");
		if(cmd.equals("add")){
			try {
				addEmployee(request,response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(cmd.equals("activate")){
			activate(request,response);
		}
		else if(cmd.equals("addMng")){
			addManager(request,response);
		}
		
	}

	private void addEmployee(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		
		int result=0;
		PrintWriter pw=null;
		String msg="";
		
		response.setContentType("text/html");
		
		String bensylid=request.getParameter("bensylid");
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String manager=request.getParameter("manager");
		int oe_id=Integer.parseInt(request.getParameter("oe_id"));
		String status="notActive";
		Employee employee=new Employee(bensylid, name, email, manager, oe_id,status);
		try {
			pw=response.getWriter();
			result=empUtil.addEmployee(employee);
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(result==1){
			msg="Successfully Added an Employee";
		}
		else if(result==-1){
			msg="Employee ID already added";
		}
		else{
			msg="Details Not Added";
		}
		List<OES> oeList=empUtil.getOES();
		List<Manager> mngList=empUtil.getManagers();
		request.setAttribute("oeList",oeList);
		request.setAttribute("mngList",mngList);
		request.setAttribute("ErrEmpAdd", msg);
		RequestDispatcher dispatcher=request.getRequestDispatcher("admin_employee.jsp");
		try {
			dispatcher.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void addManager(HttpServletRequest request,HttpServletResponse response) {
		
		Manager objManager=new Manager();
		String message="";
		objManager.setBensyl_Id( request.getParameter("manager"));
		try {
			message =empUtil.addManager1(objManager);
			if(message.equals("error")){
				request.setAttribute("lineError","the entered id is not an employee");
			}
			else if(message.equals("exist")){
				request.setAttribute("lineError","Line Manager ID already exist");	
			}
			else if(message.equals("added")){
				request.setAttribute("lineError","Successfully added the Line Manager");	
			}
			else if(message.equals("not added")){
				request.setAttribute("lineError","Line Manager not added");	
			}
		
			RequestDispatcher dispatcher= request.getRequestDispatcher("admin_employee.jsp");
			dispatcher.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void addEmp(HttpServletRequest request, HttpServletResponse response) {
		
		try {
			List<OES> oeList=empUtil.getOES();
			List<Manager> mngList=empUtil.getManagers();
			request.setAttribute("oeList",oeList);
			request.setAttribute("mngList",mngList);	
			RequestDispatcher dispatcher= request.getRequestDispatcher("admin_employee.jsp");
			dispatcher.forward(request, response);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private void activate(HttpServletRequest request, HttpServletResponse response) {
		
		String msg="";
		Employee employee=new Employee();
		employee.setBensyl_id(request.getParameter("bensylid"));
		employee.setEmp_email(request.getParameter("email"));
		employee.setPassword(request.getParameter("pass"));
		try {
			
			PrintWriter pw=response.getWriter();
			msg=empUtil.activateEmployee(employee);
			if(msg.equals("exist")){
				request.setAttribute("ErrActivate","You have already activated your account. Try forgot password");	
				RequestDispatcher dispatcher= request.getRequestDispatcher("activate.jsp");
				dispatcher.forward(request, response);
			}
			else if(msg.equals("activated")){
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Activated your account. Login with credentials');");
				pw.println("location='index.jsp';");
				pw.println("</script>");	
			}
			else if(msg.equals("NotMatch")){
				request.setAttribute("ErrActivate","Employee ID and Email Not a Match");	
				RequestDispatcher dispatcher= request.getRequestDispatcher("activate.jsp");
				dispatcher.forward(request, response);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
