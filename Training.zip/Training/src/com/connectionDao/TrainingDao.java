package com.connectionDao;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.bean.TrainingTypes;

public class TrainingDao {
	private DataSource dataSource;

	public TrainingDao() {
		super();
	}

	public TrainingDao(DataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}

	public void addTrainingDetail(HttpServletResponse response, TrainingTypes objTraining) throws SQLException {
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		int result=0;
		String tn_type="";
		String sql="insert into jithu_training_types(tn_type,tn_weightage) values(?,?)";
		String sql2="select tn_id from jithu_training_types where upper(tn_type) like ?";
		
		response.setContentType("text/html");
		tn_type=(objTraining.getTn_type()).toUpperCase();
		
		try {
			PrintWriter pw=response.getWriter();
			con=dataSource.getConnection();
			pstmt=con.prepareStatement(sql2);
			pstmt.setString(1,'%'+ tn_type+'%');
			rs=pstmt.executeQuery();
			if(rs.next()){
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Training Type alredy added');");
				pw.println("location='admin_upload.jsp';");
				pw.println("</script>");
			}
			else{
				pstmt=con.prepareStatement(sql);
				pstmt.setString(1, objTraining.getTn_type());
				pstmt.setFloat(2, objTraining.getTn_weightage());
				result=pstmt.executeUpdate();
				if(result==1){
					pw.println("<script type=\"text/javascript\">");
					pw.println("alert('Training Type added successfully');");
					pw.println("location='admin_upload.jsp';");
					pw.println("</script>");
				}
				else{
					pw.println("<script type=\"text/javascript\">");
					pw.println("alert('Error. Not added.');");
					pw.println("location='admin_upload.jsp';");
					pw.println("</script>");
				}
			}			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			con.close();
			pstmt.close();
			rs.close();
		}
	}

	public void updateTrainingDetails(HttpServletResponse response, TrainingTypes objTraining) {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement pstmt=null;
		int result=0;
		String sql="update jithu_training_types set tn_type=?,tn_weightage=? where tn_id=?";
		response.setContentType("text/html");
		
		try {
			PrintWriter pw=response.getWriter();
			con=dataSource.getConnection();
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, objTraining.getTn_type());
			pstmt.setFloat(2, objTraining.getTn_weightage());
			pstmt.setInt(3, objTraining.getTn_id());
			result=pstmt.executeUpdate();
			if(result==1){
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Training details successfully updated');");
				pw.println("location='admin_upload.jsp';");
				pw.println("</script>");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void deleteTrainingDetail(HttpServletResponse response, TrainingTypes objTraining) {
		Connection con=null;
		PreparedStatement pstmt=null;
		int result=0;
		String sql="delete from jithu_training_types where tn_id=?";
		response.setContentType("text/html");
		
		try {
			PrintWriter pw=response.getWriter();
			con=dataSource.getConnection();
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, objTraining.getTn_id());
			result=pstmt.executeUpdate();
			if(result==1){
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Training details deleted');");
				pw.println("location='admin_upload.jsp';");
				pw.println("</script>");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
