package com.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class ScoreB
 */
@WebServlet("/ScoreB")
public class ScoreB extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Resource(name="gameDB")
	static
	DataSource dataSource;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ScoreB() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		Date date=new Date(); // your date
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int year = cal.get(Calendar.YEAR);
		
		Connection con=null;
		PreparedStatement pstmt1=null,pstmt=null,pstmt2=null, pstmt3=null,pstmt4=null;
		ResultSet rs=null,rs1=null ,rs3=null;
		int weightage=0, trn_level=0, badge=0,trophy=0;
		


		String empId=null;
		String sql="select emp_id from jithu_employee";
		//String sql1="SELECT emp_id,jithu_training_detail.training_hour,jithu_training_detail.trn_det_id, jithu_training_detail.tn_id FROM JITHU_EMP_TRAINING INNER join JITHU_TRAINING_DETAIL ON JITHU_EMP_TRAINING.trn_det_id= jithu_training_detail.trn_det_id"; 
		String sql2=" update jithu_scoreboard set score=?,hours=?,trn_level=?,badge=?,trophy=? where year=? and emp_id=?";
		//String sql4=" update jithu_scoreboard set hours=? where year=? and emp_id=?";


		String sql3="select p.tn_weightage, d.training_hour from jithu_training_types p join jithu_training_detail d on p.tn_id=d.tn_id join jithu_emp_training e on d.trn_det_id= e.trn_det_id where e.emp_id=?";



		try{
			con=dataSource.getConnection();
			int result=0, result1=0;
			float score=0;
			float TotHour=0,hour=0;
			pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				score=0;
				TotHour=0;
				empId=rs.getString("emp_id");
				pstmt3=con.prepareStatement(sql3);
				pstmt3.setString(1, empId);
				rs3=pstmt3.executeQuery();
				while(rs3.next())
				{
					weightage= rs3.getInt("tn_weightage");
					hour= rs3.getFloat("training_hour");
					score= score+(hour*weightage);
					TotHour=TotHour+hour;			
				}
				trn_level=((int)score)/100;
				badge=trn_level;
				trophy=((int)TotHour)/40;
				
				pstmt2=con.prepareStatement(sql2);
				pstmt2.setFloat(1, score);
				pstmt2.setFloat(2, TotHour);
				pstmt2.setInt(3,trn_level);
				pstmt2.setInt(4,badge);
				pstmt2.setInt(5,trophy);
				pstmt2.setInt(6,year);
				pstmt2.setString(7,empId);
				result=pstmt2.executeUpdate();
			}
			
		}
		catch(NullPointerException e)
		{
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
