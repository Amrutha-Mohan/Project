package com.connectionDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import com.bean.Scores;

public class ScoreDao {
	
	private DataSource dataSource;

	public ScoreDao() {
		super();
	}

	public ScoreDao(DataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}

	public List<Scores> getScoreBoard() {
		String sql="";
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		List<Scores> scoreList=new ArrayList<Scores>();
		
		try {
			con=dataSource.getConnection();
			sql="select e.emp_id,e.emp_fname||' '||e.emp_lname as name,s.hours,s.score,s.trn_level,s.badge,s.trophy from "+
					"jithu_employee e join jithu_scoreboard s on e.emp_id=s.emp_id";
			pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			
			while(rs.next()){
				Scores objScore=new Scores();
				objScore.setEmp_id(rs.getString("emp_id"));
				objScore.setName(rs.getString("name"));
				objScore.setHours(rs.getFloat("hours"));
				objScore.setScore(rs.getFloat("score"));
				objScore.setTrn_level(rs.getInt("trn_level"));
				objScore.setBadge(rs.getInt("badge"));
				objScore.setTrophy(rs.getInt("trophy"));
				scoreList.add(objScore);				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return scoreList;
	}
	
	
	
}
