package com.connectionDao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.*;
import java.util.*;
import java.util.Date;

import javax.sql.DataSource;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;


public class UploadDao {

	private DataSource dataSource;

	public UploadDao() {
		super();
	}

	public UploadDao(DataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}

	private void createScoreBoard() {
		
		System.out.println("Inside calculating scoreboard");
		Connection con=null;
		PreparedStatement pstmt=null, pstmt2=null, pstmt3=null;
		ResultSet rs=null, rs3=null;
		int trn_level=0, badge=0, trophy=0;
		
		Date date=new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int year = cal.get(Calendar.YEAR);

		String bensyl_id="";
		String sql="select bensyl_id from jithu_employee"; 
		String sql2="update jithu_scoreboard set hours=?,trn_level=?,badge=?,trophy=? where trn_year=? and bensyl_id=?";
		String sql3="select training_hour from jithu_training_detail where bensyl_id=?";

		try{
			con=dataSource.getConnection();
			int result=0;
			float TotHour;
			pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				TotHour=0.0f;
				trn_level=0;
				badge=0;
				trophy=0;
				bensyl_id=rs.getString("bensyl_id");
				pstmt3=con.prepareStatement(sql3);
				pstmt3.setString(1, bensyl_id);
				rs3=pstmt3.executeQuery();
				while(rs3.next())
				{
					TotHour=(TotHour+(rs3.getFloat("training_hour")));
				}
				if(TotHour<40){
					trn_level=0;
				}
				else if(TotHour>=40 && TotHour<150){
					trn_level=1;
					trophy=1;
				}
				else if(TotHour>=150 && TotHour<300){
					trn_level=2;
				}
				else if(TotHour>=300 && TotHour<500){
					trn_level=3;
				}
				else if(TotHour>=500){
					trn_level=4;
					int val=(int) (TotHour-500);
					val=val/250;
					badge=val;
				}

				pstmt2=con.prepareStatement(sql2);
				pstmt2.setFloat(1, TotHour);
				pstmt2.setInt(2,trn_level);
				pstmt2.setInt(3,badge);
				pstmt2.setInt(4,trophy);
				pstmt2.setInt(5,year);
				pstmt2.setString(6,bensyl_id);
				result=pstmt2.executeUpdate();
			}

		}
		catch(NullPointerException e)
		{
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				con.close();
				if(pstmt!=null){
					pstmt.close();
				}
				if(pstmt2!=null){
					pstmt2.close();
				}
				if(pstmt3!=null){
					pstmt2.close();
				}
				if(rs!=null){
					rs.close();
				}
				if(rs3!=null){
					rs3.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void deleteTables() throws SQLException{
		Connection con=null;
		PreparedStatement pstmt=null;
		String sql="";
		int result=0;

		try {
			con=dataSource.getConnection();
			sql="delete from jithu_training_detail";
			pstmt=con.prepareStatement(sql);
			result=pstmt.executeUpdate();		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			con.close();
			pstmt.close();
		}
	}

	public int readFromExcelFile(String fileName) throws SQLException {
		int result=0;
		Float hour=0.0f;
		String sql="";
		Connection con=null;
		PreparedStatement pstmt=null;
		
		int FR=1;
		int LR=2224;
		int FC = 0;
		int LC = 9;

		try {
			
			deleteTables();

			FileInputStream fStream = new FileInputStream(fileName);
			POIFSFileSystem fSystem = new POIFSFileSystem(fStream);
			HSSFWorkbook workBook = new HSSFWorkbook(fSystem);
			HSSFSheet mySheet = workBook.getSheetAt(0);
			con=dataSource.getConnection();
			for (int i = FR; i <= LR; i++) {
				List<HSSFCell> cellHolder = new ArrayList<HSSFCell>();
				HSSFRow r = mySheet.getRow(i);
				for (int j = FC; j <= LC; j++) {
						HSSFCell c = r.getCell(j);
						cellHolder.add(c);
				}

				//insert into training_details
				sql="insert into jithu_training_detail(bensyl_id,trn_name,training_hour,trn_date) values(?,?,?,?)";
				pstmt=con.prepareStatement(sql);
				pstmt.setString(1, ((HSSFCell) cellHolder.get(1)).toString());
				pstmt.setString(2, ((HSSFCell) cellHolder.get(7)).toString());
				hour=Float.parseFloat(((HSSFCell) cellHolder.get(9)).toString());
				pstmt.setFloat(3, hour);
				pstmt.setString(4, ((HSSFCell) cellHolder.get(8)).toString());
				result=pstmt.executeUpdate();

			}
			//call method to update score board
			createScoreBoard();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			con.close();
			pstmt.close();
		}
		return 1;
	}
}
