package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.bean.Employee;
import com.connectUtil.EmployeeUtil;

/**
 * Servlet implementation class EmployeeController
 */
@WebServlet("/EmployeeController")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private EmployeeUtil empUtil;

	@Resource(name="gameDB")
	private DataSource dataSource;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeController() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    @Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		empUtil=new EmployeeUtil(dataSource);
	}



	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		int result=0;
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		
		String cmd=request.getParameter("cmd");
		if(cmd.equals("add")){
			String id=request.getParameter("empid");
			String fname=request.getParameter("fname");
			String lname=request.getParameter("lname");
			String email=request.getParameter("email");
			String manager=request.getParameter("manager");
			Employee employee=new Employee(id, fname, lname, email, manager);
			try {
				result=empUtil.addEmployee(employee);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(result==1){
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Successfully Added an Employee');");
				pw.println("location='admin_home.jsp';");
				pw.println("</script>");
			}
		}
		
	}

}
