package com.connectUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.bean.Employee;

public class EmployeeUtil {
	
	private DataSource dataSource;

	public EmployeeUtil() {
		super();
	}

	public EmployeeUtil(DataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}
	
	public int addEmployee(Employee employee) throws SQLException{
		Connection con=null;
		PreparedStatement pstmt=null;
		int result=0;
		String sql="insert into jithu_employee(emp_id,emp_fname,emp_lname,emp_email,linemng_id) values(?,?,?,?,?)";
		
		try {
			con=dataSource.getConnection();
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, employee.getEmp_id());
			pstmt.setString(2, employee.getEmp_fname());
			pstmt.setString(3, employee.getEmp_lname());
			pstmt.setString(4, employee.getEmp_email());
			pstmt.setString(5, employee.getLinemng_id());
			result=pstmt.executeUpdate();
			System.out.println(result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			pstmt.close();
			con.close();
		}
		return result;
	}
}
