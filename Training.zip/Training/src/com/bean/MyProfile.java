package com.bean;

public class MyProfile {
	
	private String tn_Type;
	private String trn_Name;
	private String trainer;
	private float training_Hour;
	private String trn_Date;
	
	public MyProfile() {
		super();
	}
	
	public MyProfile(String tn_Type, String trn_Name, String trainer, float training_Hour, String trn_Date) {
		super();
		this.tn_Type = tn_Type;
		this.trn_Name = trn_Name;
		this.trainer = trainer;
		this.training_Hour = training_Hour;
		this.trn_Date = trn_Date;
	}

	public String getTn_Type() {
		return tn_Type;
	}

	public void setTn_Type(String tn_Type) {
		this.tn_Type = tn_Type;
	}

	public String getTrn_Name() {
		return trn_Name;
	}

	public void setTrn_Name(String trn_Name) {
		this.trn_Name = trn_Name;
	}

	public String getTrainer() {
		return trainer;
	}

	public void setTrainer(String trainer) {
		this.trainer = trainer;
	}

	public float getTraining_Hour() {
		return training_Hour;
	}

	public void setTraining_Hour(float training_Hour) {
		this.training_Hour = training_Hour;
	}

	public String getTrn_Date() {
		return trn_Date;
	}

	public void setTrn_Date(String trn_Date) {
		this.trn_Date = trn_Date;
	}	
	
}
