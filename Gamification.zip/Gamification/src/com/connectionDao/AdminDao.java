package com.connectionDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.bean.Admin;
import com.bean.Employee;
import com.dbCon.DBConnection;
import com.listeners.CredentialListener;

public class AdminDao implements CredentialListener{
	
			//private DataSource dataSource;

	public AdminDao() {
		super();
	}

			/*public AdminDao(DataSource dataSource) {
				super();
				this.dataSource = dataSource;
			}*/	

	@Override
	public int passwordCheck(Object obj) throws SQLException {
		
				//Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs1=null;
		String msg="",sql="";
		int result=0;
		DBConnection dbCon=new DBConnection();
		
		try {
					//con=dataSource.getConnection();
			if(obj instanceof Admin){
				Admin admObj=(Admin)obj;
				sql="select password from game_admin where emp_email=? and password=?";
						//pstmt=con.prepareStatement(sql);
				pstmt=dbCon.getStatement(sql);
				pstmt.setString(1, admObj.getEmp_email());
				pstmt.setString(2, admObj.getPassword());
				rs1=pstmt.executeQuery();
				if(rs1.next()){
					result = 1;
				}
				else{
					result = -1;
				}
			}			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
					//con.close();
			pstmt.close();
			rs1.close();
		}
		return result;		
	}

	@Override
	public String changePass(Object obj) throws SQLException {
		
				//Connection con=null;
		PreparedStatement pstmt=null;
		String msg="",sql="";
		int result=0;
		DBConnection dbCon=new DBConnection();
		
		try {
					//con=dataSource.getConnection();
			if(obj instanceof Admin){
				Admin admObj=(Admin)obj;
				sql="update game_admin set password=? where emp_email=?";
						//pstmt=con.prepareStatement(sql);
				pstmt=dbCon.getStatement(sql);
				pstmt.setString(1, admObj.getPassword());
				pstmt.setString(2, admObj.getEmp_email());
				result=pstmt.executeUpdate();
				if(result==1){
					msg="changed";
				}
				else{
					msg="notChanged";
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
					//con.close();
			pstmt.close();
		}
		return msg;
	}
	
}
