package com.controller;

import javax.sql.DataSource;

public class NewDao {
	private DataSource dataSource;
	
}
