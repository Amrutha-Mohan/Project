package com.bean;

public class Employee {

	private String emp_id;
	private String emp_name;
	private String emp_email;
	private String  linemng_id;
	private String password;
	private String status;
	private int oe_id;
	private String bensyl_id;
	
	public Employee() {
		super();
	}

	public Employee(String emp_id, String emp_name, String emp_email, String linemng_id, String password,
			String status, int oe_id, String bensyl_id) {
		super();
		this.emp_id = emp_id;
		this.emp_name = emp_name;
		this.emp_email = emp_email;
		this.linemng_id = linemng_id;
		this.password = password;
		this.status = status;
		this.oe_id = oe_id;
		this.bensyl_id = bensyl_id;
	}

	public Employee(String bensylid, String name, String email, String manager, int oe_id2, String status2) {
		super();
		this.bensyl_id = bensylid;
		this.emp_name = name;
		this.emp_email = email;
		this.linemng_id = manager;
		this.status = status2;
		this.oe_id = oe_id2;
	}

	public Employee(String bensyl_Id2, String newPass) {
		this.password = newPass;
		this.bensyl_id = bensyl_Id2;
	}

	public String getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public String getEmp_email() {
		return emp_email;
	}

	public void setEmp_email(String emp_email) {
		this.emp_email = emp_email;
	}

	public String getLinemng_id() {
		return linemng_id;
	}

	public void setLinemng_id(String linemng_id) {
		this.linemng_id = linemng_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getOe_id() {
		return oe_id;
	}

	public void setOe_id(int oe_id) {
		this.oe_id = oe_id;
	}

	public String getBensyl_id() {
		return bensyl_id;
	}

	public void setBensyl_id(String bensyl_id) {
		this.bensyl_id = bensyl_id;
	}	
}

