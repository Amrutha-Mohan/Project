package com.bean;

public class Scoreboard {
	private int year;
	private String emp_id;
	private float hours;
	private float score;
	private int trn_level;
	private int badge;
	private int trophy;

	public Scoreboard() {
		super();
	}

	public Scoreboard(int year, String emp_id, float hours, float score, int trn_level, int badge, int trophy) {
		super();
		this.year = year;
		this.emp_id = emp_id;
		this.hours = hours;
		this.score = score;
		this.trn_level = trn_level;
		this.badge = badge;
		this.trophy = trophy;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}

	public float getHours() {
		return hours;
	}

	public void setHours(float hours) {
		this.hours = hours;
	}

	public float getScore() {
		return score;
	}

	public void setScore(float score) {
		this.score = score;
	}

	public int getTrn_level() {
		return trn_level;
	}

	public void setTrn_level(int trn_level) {
		this.trn_level = trn_level;
	}

	public int getBadge() {
		return badge;
	}

	public void setBadge(int badge) {
		this.badge = badge;
	}

	public int getTrophy() {
		return trophy;
	}

	public void setTrophy(int trophy) {
		this.trophy = trophy;
	}	

}
