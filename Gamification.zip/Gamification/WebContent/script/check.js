/**
 * 
 */

function validateID(id){
	var RegExp1=/^(?=.*?[a-zA-Z])(?=.*?[0-9]).{6,7}$/;
	if(id.match(RegExp1)){
		return true;
	}
	else{
		alert("Not a valid Bensyl or Staff ID");
		return false;
	}
}

function validateUserName(userName){
	var RegExp1=/^(?=.*?[a-zA-Z])(?=.*?[0-9]).{6,7}$/;
	var RegExp2 = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	if(userName.match(RegExp1) || userName.match(RegExp2)){
		return true;
	}
	else{
		alert("Not a valid UserName");
		return false;
	}
}

function validateName(name){

	var RegExp=/^[a-zA-Z ]+$/;
	if(!(name.match(RegExp))){
		alert("Only letters and white space allowed");
		return false;
	}
	else{
		return true;
	}
}

function checkEmp(){
	
	if(document.empForm.manager.value=="select"){
		alert("Select a line manager");
		return false;
	}
	else if(document.empForm.oe_id.value=="select"){
		alert("Select an OE");
		return false;
	}
	else{
		return true;
	}
}

function validatePassAdmin(pass){
	
	var RegExp=/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
	if(!(pass.match(RegExp))){
		alert("Password : Atleast one UpperCase,one LowerCase, one Number, one special character and minimum 8 characters");
		return false;
	}
	else if(pass.match(RegExp)){
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("passMsg").innerHTML =
					this.responseText;
			}
		};
		xhttp.open("POST", "AdminController?pass="+pass+"&cmd=oldPA", true);
		xhttp.send();		
	}
	else{
		return true;
	}
	
}

function validatePass(pass){
	
	var RegExp=/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
	if(!(pass.match(RegExp))){
		alert("Password : Atleast one UpperCase,one LowerCase, one Number, one special character and minimum 8 characters");
		return false;
	}
	else{
		return true;
	}
	
}

function validatePassUser(pass){
	
	var RegExp=/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
	if(!(pass.match(RegExp))){
		alert("Password : Atleast one UpperCase,one LowerCase, one Number, one special character and minimum 8 characters");
		return false;
	}
	else if(pass.match(RegExp)){
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("passMsg").innerHTML =
					this.responseText;
			}
		};
		xhttp.open("POST", "EmployeeController?pass="+pass+"&cmd=oldPA", true);
		xhttp.send();		
	}
	else{
		return true;
	}
	
}

validatePassUser

function checkPass(){
	var newpass1=document.changePass.newpass1.value;
	var newpass2=document.changePass.newpass2.value;
	if(newpass1!=newpass2){
		alert("Password Mismatch");
		document.changePass.newpass1.value="";
		document.changePass.newpass2.value="";
		return false;
	}
	else{
		return true;
	}
}

function validateName1(name){
	var RegExp=/^([a-zA-Z]+\s)*[a-zA-Z]+$/;
	if(name.match(RegExp)){
		return true;
	}
	else{
		alert("Not a valid Name");
		document.empForm.name.value="";
		return false;
	}
}

function validateYear(year){
	var RegExp=/^[1-2]\d{3}$/;
	var yearNum=Number(year);
	var date=new Date;
	var checkYear=date.getFullYear();
	if(!(year.match(RegExp))){
		alert("Not a valid Year");
		document.uploadForm.trn_year.value="";
		return false;
	}
	else if(yearNum>checkYear){
		alert("Training data not available for this year");
		document.uploadForm.trn_year.value="";
		return false;
	}
	else{
		return true;
	}
}

function validateExtension(fileName){
	var ext=".xls";
	if(fileName.length > 0) {
		var blnValid = 0;
		var len2=fileName.length - ext.length;
		var subFileName=fileName.substr(len2, ext.length);
		if (subFileName == ext) {
			return true;
		}
		else{
			alert("Not a correct extension");
			return false;
		}
	}
}


