/*
 *Interface to listen login and password change behaviour. 
 */
package com.listeners;

import java.sql.SQLException;

public interface CredentialListener {
	
	public int passwordCheck(Object obj) throws SQLException;
	public String changePass(Object obj) throws SQLException;
}
