package com.connectionDao;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.*;
import java.util.*;
import java.util.Date;
import java.util.List;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.*;
import javax.sql.DataSource;

import com.bean.Scores;
import com.dbCon.DBConnection;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

public class ReportDao {

	private DataSource dataSource;

	public ReportDao() {
		super();
	}

	public ReportDao(DataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}

	public List<Scores> getTrainingDetails(String mngId) throws SQLException {

		List<Scores> listTrns=new ArrayList<Scores>();
				//Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs1=null;
		String sql="";
		DBConnection dbCon=new DBConnection();

		try {
					//con=dataSource.getConnection();
			sql="select e.emp_name,e.bensyl_id,s.hours,s.trn_level,s.badge,s.trophy "+
					"from game_scoreboard s join game_employee e on e.bensyl_id=s.bensyl_id where e.linemng_id=?";
					//pstmt=con.prepareStatement(sql);
			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, mngId);
			rs1=pstmt.executeQuery();
			while(rs1.next()){
				Scores objScr=new Scores();
				objScr.setBensyl_id(rs1.getString("bensyl_id"));
				objScr.setName(rs1.getString("emp_name"));
				objScr.setHours(rs1.getFloat("hours"));
				objScr.setTrn_level(rs1.getInt("trn_level"));
				objScr.setBadge(rs1.getInt("badge"));
				objScr.setTrophy(rs1.getInt("trophy"));
				listTrns.add(objScr);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
					//con.close();
			pstmt.close();
			rs1.close();
		}
		return listTrns;
	}


	public int downloadPDF(String bensyl_id, String email) throws SQLException {

				//Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null, rs2=null;
		String path="", sql="", name="", newName="", newBensyl="";
		Document document=null;
		PdfWriter writer=null;
		DBConnection dbCon=new DBConnection();

		System.out.println("download pdf");

		try {

					//con=dataSource.getConnection();
			sql="select emp_name from game_employee where bensyl_id=?";
					//pstmt=con.prepareStatement(sql);
			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, bensyl_id);
			rs2=pstmt.executeQuery();
			if(rs2.next()){
				name=rs2.getString("emp_name");
			}
			else{
				name="Name";
			}
			sql="select e.emp_name,e.bensyl_id,s.hours,s.trn_level,s.badge,s.trophy "+
					"from game_scoreboard s join game_employee e on e.bensyl_id=s.bensyl_id where e.linemng_id=?";
					//pstmt=con.prepareStatement(sql);
			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, bensyl_id);
			rs=pstmt.executeQuery();


			document = new Document(PageSize.A4, 10, 10, 10, 10);			
			String home = System.getProperty("user.home");
			File file = new File(home+"/Downloads/" + name+"_"+bensyl_id + ".pdf"); 
			path=file.getAbsolutePath();			
			writer = PdfWriter.getInstance(document,new FileOutputStream(path));
			document.open();

			newName="Line Manager Name : "+name;
			newBensyl="Bensyl ID : "+bensyl_id;

			Paragraph para1 = new Paragraph("Employee Training Details",FontFactory.getFont(FontFactory.HELVETICA, 16, Font.BOLD, new CMYKColor(55, 35, 0, 33)));
			Paragraph para2 = new Paragraph(newName,FontFactory.getFont(FontFactory.HELVETICA, 13, Font.BOLD, new CMYKColor(0, 40, 40, 100)));
			Paragraph para3 = new Paragraph(newBensyl,FontFactory.getFont(FontFactory.HELVETICA, 13, Font.BOLD, new CMYKColor(0, 40, 40, 100)));
			document.add(para1);
			document.add(para2);
			document.add(para3);

			PdfPTable t = new PdfPTable(6);
			t.setSpacingBefore(25);
			t.setSpacingAfter(25);
			PdfPCell c1 = new PdfPCell(new Phrase("Employee Name"));		t.addCell(c1);
			PdfPCell c2 = new PdfPCell(new Phrase("Bensyl Id"));			t.addCell(c2);
			PdfPCell c3 = new PdfPCell(new Phrase("Hour"));					t.addCell(c3);
			PdfPCell c4 = new PdfPCell(new Phrase("Training Level"));		t.addCell(c4);
			PdfPCell c5 = new PdfPCell(new Phrase("Badge"));				t.addCell(c5);
			PdfPCell c6 = new PdfPCell(new Phrase("Trophy"));				t.addCell(c6);

			while(rs.next()){

				t.addCell(rs.getString("emp_name"));
				t.addCell(rs.getString("bensyl_id"));
				t.addCell(Float.toString(rs.getFloat("hours")));
				t.addCell(Integer.toString(rs.getInt("trn_level")));
				t.addCell(Integer.toString(rs.getInt("badge")));
				t.addCell(Integer.toString(rs.getInt("trophy")));

			}
			document.add(t);

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace();
		}
		finally {
					//con.close();
			pstmt.close();
			rs2.close();
			rs.close();
			document.close();
		}		
		sendEmail(path,bensyl_id,email);
		return 1;
	}

	private void sendEmail(String attachmentName, String bensyl_id, String from) {

				//Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null, rs2=null;
		String sql="";
		String name="", to="", subject="", body="";
		DBConnection dbCon=new DBConnection();

		try {
					//con=dataSource.getConnection();
			sql="select emp_name,emp_email from game_employee where bensyl_id=?";
					//pstmt=con.prepareStatement(sql);
			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, bensyl_id);
			rs=pstmt.executeQuery();
			if(rs.next()){
				name=rs.getString("emp_name");
				to=rs.getString("emp_email");
			}

			to="extern_mohan.amrutha@allianz.com";
			from = "extern_mohan.amrutha@allianz.com";
			Date date=new Date();
			String dt=date.toString();
			subject="Training Report on "+dt;
			body="Hi "+name+"\n\nPDF with training details is attached. "+subject+"\n\nThanks and Regards";

			// Assuming you are sending email from localhost
			String host = "tmu-econ.mail.allianz";

			// Get system properties
			Properties properties = System.getProperties();

			// Setup mail server
			properties.setProperty("mail.smtp.host", host);

			// Get the default Session object.
			Session session = Session.getDefaultInstance(properties);

			// Create a default MimeMessage object.
			MimeMessage message = new MimeMessage(session);

			// Set From: header field of the header.
			message.setFrom(new InternetAddress(from));

			// Set To: header field of the header.
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

			// Set Subject: header field
			message.setSubject(subject);

			MimeBodyPart messagePart = new MimeBodyPart();

			// Now set the actual message
			messagePart.setText(body);

			// Set the email attachment file

			FileDataSource fileDataSource = new FileDataSource(attachmentName);
			MimeBodyPart attachmentPart = new MimeBodyPart();
			attachmentPart.setDataHandler(new DataHandler(fileDataSource));
			attachmentPart.setFileName(fileDataSource.getName());
			MimeMultipart multipart = new MimeMultipart();
			multipart.addBodyPart(messagePart);
			multipart.addBodyPart(attachmentPart);
			message.setContent(multipart);

			// Send message
			Transport.send(message);
		} 
		catch (MessagingException mex) {
			mex.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}	
}
