package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.bean.Admin;
import com.bean.Employee;
import com.connectionDao.CredentialDao;
import com.connectionDao.EmployeeDao;

/**
 * Servlet implementation class CredentialController
 */
@WebServlet("/CredentialController")
public class CredentialController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private CredentialDao crdUtil;

	@Resource(name="gameDB")
	private DataSource dataSource;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CredentialController() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    @Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		crdUtil=new CredentialDao(dataSource);
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		/*HttpSession session = request.getSession(false);
		String uname = (String) session.getAttribute("uname");
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Cache-Control", "no-store");
		response.setDateHeader("Expires", 0);
		response.setHeader("Pragma", "no-cache");
		if (null == uname) {
			request.setAttribute("Error", "Session has ended. Please login again.");
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		}*/
		
		String cmd=request.getParameter("cmd");
		if(cmd.equals("logout")){
			logout(request,response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
		/*HttpSession session = request.getSession(false);
		String uname = (String) session.getAttribute("uname");
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Cache-Control", "no-store");
		response.setDateHeader("Expires", 0);
		response.setHeader("Pragma", "no-cache");
		if (null == uname) {
			request.setAttribute("Error", "Session has ended. Please login again.");
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		}*/
				
		String cmd=request.getParameter("cmd");
		if(cmd.equals("admChange")){
			adminChange(request,response);
		}
		else if(cmd.equals("login")){
			login(request,response);
		}
		else if(cmd.equals("userChange")){
			userChange(request,response);
		}
	}

	private void userChange(HttpServletRequest request, HttpServletResponse response) {
		
		String msg="";
		HttpSession session = request.getSession(false);
		String bensyl_Id=(String)session.getAttribute("uname");
		String newPass=request.getParameter("newpass1");
		String curPass=request.getParameter("pass");
		Employee employee=new Employee(bensyl_Id,newPass);
		
		try {
			PrintWriter pw= response.getWriter();
			msg=crdUtil.userChangePass(employee,curPass);
			if(msg.equals("incorrect")){
				request.setAttribute("changeErr","Current Password is Incorrect");
				RequestDispatcher dispatcher= request.getRequestDispatcher("user_changepass.jsp");
				dispatcher.forward(request, response);
			}
			else if(msg.equals("notChanged")){
				request.setAttribute("changeErr","Password not changed");
				RequestDispatcher dispatcher= request.getRequestDispatcher("user_changepass.jsp");
				dispatcher.forward(request, response);
			}
			else if(msg.equals("changed")){
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Password Changed. Login with New Password');");
				pw.println("location='index.jsp';");
				pw.println("</script>");
			}				
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void login(HttpServletRequest request, HttpServletResponse response) {
		
		String uname= request.getParameter("uname");
		String pass= request.getParameter("pass");
		String msg="";
		try {
			
			HttpSession session = request.getSession(true);
			msg=crdUtil.login(uname,pass);
			if(msg.equals("admin")){
				session.setAttribute("uname", uname);
				response.sendRedirect("admin_home.jsp");
			}
			else if(msg.equals("employee")){
				session.setAttribute("uname", uname);
				response.sendRedirect("user_home.jsp");
			}
			else if(msg.equals("invalid")){
				request.setAttribute("ErrLogin","UserName or Password Incorrect");
				RequestDispatcher dispatcher= request.getRequestDispatcher("index.jsp");
				dispatcher.forward(request, response);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void adminChange(HttpServletRequest request, HttpServletResponse response) {
		
		String msg="";
		HttpSession session = request.getSession(false);
		String emp_email=(String)session.getAttribute("uname");
		String newPass=request.getParameter("newpass1");
		String curPass=request.getParameter("pass");
		Admin admin=new Admin(emp_email,newPass);
		
		try {
			PrintWriter pw= response.getWriter();
			msg=crdUtil.adminChangePass(admin,curPass);
			if(msg.equals("incorrect")){
				request.setAttribute("changeErr","Current Password is Incorrect");
				RequestDispatcher dispatcher= request.getRequestDispatcher("admin_changepass.jsp");
				dispatcher.forward(request, response);
			}
			else if(msg.equals("notChanged")){
				request.setAttribute("changeErr","Password not changed");
				RequestDispatcher dispatcher= request.getRequestDispatcher("admin_changepass.jsp");
				dispatcher.forward(request, response);
			}
			else if(msg.equals("changed")){
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Password Changed. Login with New Password');");
				pw.println("location='index.jsp';");
				pw.println("</script>");
			}				
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	

	private void logout(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession session = request.getSession(false);
		if(session!=null){
			session.invalidate();
			try {
				response.sendRedirect("index.jsp");
			}  catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}

}
