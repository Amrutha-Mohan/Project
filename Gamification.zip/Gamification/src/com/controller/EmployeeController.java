package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.bean.Admin;
import com.bean.Employee;
import com.bean.Manager;
import com.bean.OES;
import com.connectionDao.EmployeeDao;

/**
 * Servlet implementation class EmployeeController
 */
@WebServlet("/EmployeeController")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private EmployeeDao empDao;

			/*@Resource(name="gameDB")
			private DataSource dataSource;*/

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EmployeeController() {
		super();
	}

	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
				/*empDao=new EmployeeDao(dataSource);*/
		empDao=new EmployeeDao();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String cmd=request.getParameter("cmd");
		if(cmd.equals("AddEmp")){
			addEmp(request,response);
		}
		else if(cmd.equals("searchEmp")){
			searchEmp(request,response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String cmd=request.getParameter("cmd");
		if(cmd.equals("add")){
			try {
				addEmployee(request,response);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		else if(cmd.equals("activate")){
			activate(request,response);
		}
		else if(cmd.equals("addMng")){
			addManager(request,response);
		}
		else if(cmd.equals("oldPA")){
			userPassCheck(request,response);
		}
		else if(cmd.equals("userChange")){
			changePass(request,response);
		}

	}

	private void changePass(HttpServletRequest request, HttpServletResponse response) {

		String msg="";
		HttpSession session = request.getSession(false);
		String bensyl_Id=(String)session.getAttribute("uname");
		String newPass=request.getParameter("newpass1");
		Employee employee=new Employee(bensyl_Id,newPass);

		try {
			PrintWriter pw= response.getWriter();
			msg=empDao.changePass(employee);
			if(msg.equals("notChanged")){
				request.setAttribute("changeErr","Password not changed");
				RequestDispatcher dispatcher= request.getRequestDispatcher("user_changepass.jsp");
				dispatcher.forward(request, response);
			}
			else if(msg.equals("changed")){
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Password Changed. Login with New Password');");
				pw.println("location='index.jsp';");
				pw.println("</script>");
			}				

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ServletException e) {
			e.printStackTrace();
		}
	}

	private void userPassCheck(HttpServletRequest request, HttpServletResponse response) {

		int result=0;
		Employee empObj=new Employee();
		HttpSession session = request.getSession(false);
		String bensyl_id=(String)session.getAttribute("uname");
		empObj.setPassword(request.getParameter("pass"));
		empObj.setBensyl_id(bensyl_id);
		try {

			PrintWriter pw=response.getWriter();
			result=empDao.passwordCheck(empObj);
			if(result == -1){
				pw.println("Wrong Password");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private void addEmployee(HttpServletRequest request, HttpServletResponse response) throws SQLException {

		int result=0;
		String msg="";

		String bensylid=(request.getParameter("bensylid")).toUpperCase();
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String manager=request.getParameter("manager");
		int oe_id=Integer.parseInt(request.getParameter("oe_id"));
		String status="notActive";
		Employee employee=new Employee(bensylid, name, email, manager, oe_id,status);
		try {

			result=empDao.addEmployee(employee);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(result==1){
			msg="Successfully Added an Employee";
		}
		else if(result==-1){
			msg="Employee ID already added";
		}
		else{
			msg="Details Not Added";
		}
		List<OES> oeList=empDao.getOES();
		List<Employee> mngList=empDao.getManagers();
		request.setAttribute("oeList",oeList);
		request.setAttribute("mngList",mngList);
		request.setAttribute("ErrEmpAdd", msg);
		RequestDispatcher dispatcher=request.getRequestDispatcher("admin_employee.jsp");
		try {
			dispatcher.forward(request, response);
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void addManager(HttpServletRequest request,HttpServletResponse response) {

		Manager objManager=new Manager();
		String message="";
		String bensyl_id=(request.getParameter("manager")).toUpperCase();
		objManager.setBensyl_Id(bensyl_id);
		try {
			message =empDao.addManager1(objManager);
			if(message.equals("error")){
				request.setAttribute("lineError","Entered Bensyl ID is not an Employee");
			}
			else if(message.equals("exist")){
				request.setAttribute("lineError","Line Manager ID already exist");	
			}
			else if(message.equals("added")){
				request.setAttribute("lineError","Successfully added the Line Manager");	
			}
			else if(message.equals("not added")){
				request.setAttribute("lineError","Line Manager not added");	
			}

			RequestDispatcher dispatcher= request.getRequestDispatcher("admin_employee.jsp");
			dispatcher.forward(request, response);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void addEmp(HttpServletRequest request, HttpServletResponse response) {

		try {
			List<OES> oeList=empDao.getOES();
			List<Employee> mngList=empDao.getManagers();
			request.setAttribute("oeList",oeList);
			request.setAttribute("mngList",mngList);	
			RequestDispatcher dispatcher= request.getRequestDispatcher("admin_employee.jsp");
			dispatcher.forward(request, response);

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private void activate(HttpServletRequest request, HttpServletResponse response) {

		String msg="";
		Employee employee=new Employee();
		employee.setBensyl_id(request.getParameter("bensylid"));
		employee.setEmp_email(request.getParameter("email"));
		employee.setPassword(request.getParameter("pass"));
		try {

			PrintWriter pw=response.getWriter();
			msg=empDao.activateEmployee(employee);
			if(msg.equals("exist")){
				request.setAttribute("ErrActivate","You have already activated your account. Try forgot password");	
				RequestDispatcher dispatcher= request.getRequestDispatcher("activate.jsp");
				dispatcher.forward(request, response);
			}
			else if(msg.equals("activated")){
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Activated your account. Login with credentials');");
				pw.println("location='index.jsp';");
				pw.println("</script>");	
			}
			else if(msg.equals("NotMatch")){
				request.setAttribute("ErrActivate","Employee ID and Email Not a Match");	
				RequestDispatcher dispatcher= request.getRequestDispatcher("activate.jsp");
				dispatcher.forward(request, response);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ServletException e) {
			e.printStackTrace();
		}
	}


	
	private void searchEmp(HttpServletRequest request, HttpServletResponse response) {

		String bensyl_id=(request.getParameter("val")).toUpperCase();
		Employee objEmp;
		try {
			
			//get details of employee with given bensyl_id
			objEmp=empDao.getEmployee(bensyl_id);
			request.setAttribute("objEmp",objEmp);
			RequestDispatcher dispatcher= request.getRequestDispatcher("employee_edit.jsp");
			
			//forward the request to employee_edit.jsp
			dispatcher.forward(request, response);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
