package com.bean;

public class TrainingDetail {
	
	private int trn_number;
	private String emp_id;
	private int tn_id;
	private String trn_name;
	private String trainer;
	private float trn_hour;
	private String trn_date;
	
	public TrainingDetail() {
		super();
	}
	
	public TrainingDetail(int trn_number, String emp_id, int tn_id, String trn_name, String trainer, float trn_hour,
			String trn_date) {
		super();
		this.trn_number = trn_number;
		this.emp_id = emp_id;
		this.tn_id = tn_id;
		this.trn_name = trn_name;
		this.trainer = trainer;
		this.trn_hour = trn_hour;
		this.trn_date = trn_date;
	}
	
	public int getTrn_number() {
		return trn_number;
	}
	
	public void setTrn_number(int trn_number) {
		this.trn_number = trn_number;
	}
	
	public String getEmp_id() {
		return emp_id;
	}
	
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	
	public int getTn_id() {
		return tn_id;
	}
	
	public void setTn_id(int tn_id) {
		this.tn_id = tn_id;
	}
	
	public String getTrn_name() {
		return trn_name;
	}
	
	public void setTrn_name(String trn_name) {
		this.trn_name = trn_name;
	}
	
	public String getTrainer() {
		return trainer;
	}
	
	public void setTrainer(String trainer) {
		this.trainer = trainer;
	}
	
	public float getTrn_hour() {
		return trn_hour;
	}
	
	public void setTrn_hour(float trn_hour) {
		this.trn_hour = trn_hour;
	}
	
	public String getTrn_date() {
		return trn_date;
	}
	
	public void setTrn_date(String trn_date) {
		this.trn_date = trn_date;
	}

}
