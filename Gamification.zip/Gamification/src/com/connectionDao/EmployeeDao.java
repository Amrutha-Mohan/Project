package com.connectionDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import javax.sql.DataSource;

import com.bean.Employee;
import com.bean.Manager;
import com.bean.OES;
import com.dbCon.DBConnection;
import com.listeners.CredentialListener;


public class EmployeeDao implements CredentialListener{
	
			//private DataSource dataSource;

	public EmployeeDao() {
		super();
	}

			/*public EmployeeDao(DataSource dataSource) {
				super();
				this.dataSource = dataSource;
			}*/
	
	public int addEmployee(Employee employee) throws SQLException{
		
				//Connection con=null;
		PreparedStatement pstmt=null,pstmt2=null,pstmt3=null,pstmt4=null;
		ResultSet rs=null,rs2=null;
		int result=0;
		String date="";
		DBConnection dbCon=new DBConnection();
		
		String sql4="select bensyl_id from game_employee where upper(bensyl_id)=?";
		String sql="insert into game_employee(bensyl_id,emp_name,emp_email,linemng_id,status,oe_id) values(?,?,?,?,?,?)";
		String sql2="insert into game_scoreboard values(?,?,?,?,?,?)";
		String sql3="select to_char(sysdate, 'YYYY') from dual";
		
		try {
					/*con=dataSource.getConnection();		
					pstmt4=con.prepareStatement(sql4);*/
			pstmt4=dbCon.getStatement(sql4);
			pstmt4.setString(1, employee.getBensyl_id());
			rs2=pstmt4.executeQuery();
			if(rs2.next()){
				return -1;
			}
			else{	
						//pstmt=con.prepareStatement(sql);
				pstmt=dbCon.getStatement(sql);
				pstmt.setString(1, employee.getBensyl_id());
				pstmt.setString(2, employee.getEmp_name());
				pstmt.setString(3, employee.getEmp_email());
				pstmt.setString(4, employee.getLinemng_id());
				pstmt.setString(5, employee.getStatus());
				pstmt.setInt(6, employee.getOe_id());
				result=pstmt.executeUpdate();
						//pstmt3=con.prepareStatement(sql3);
				pstmt3=dbCon.getStatement(sql3);
				rs=pstmt3.executeQuery();
				if(rs.next()){
					date=rs.getString(1);
				}
						//pstmt2=con.prepareStatement(sql2);
				pstmt2=dbCon.getStatement(sql2);
				pstmt2.setString(1, date);
				pstmt2.setString(2, employee.getBensyl_id());
				pstmt2.setDouble(3, 0);
				pstmt2.setInt(4, 0);
				pstmt2.setInt(5, 0);
				pstmt2.setInt(6, 0);
				result=pstmt2.executeUpdate();
			}					
					
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
					/*if(con!=null){
						con.close();
					}*/			
			if(pstmt!=null){
				pstmt.close();
			}
			if(pstmt2!=null){
				pstmt2.close();
			}
			if(pstmt3!=null){
				pstmt3.close();
			}
			if(pstmt4!=null){
				pstmt4.close();
			}
			if(rs!=null){
				rs.close();
			}
			if(rs2!=null){
				rs2.close();
			}			
		}
		return result;
	}

	@SuppressWarnings("resource")
	public String activateEmployee(Employee employee) throws SQLException {
		
				//Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		int result=0;
		String status="",msg="null";
		String sql="select status from game_employee where bensyl_id=? and emp_email=?";
		DBConnection dbCon=new DBConnection();
		
		try {
			
					/*con=dataSource.getConnection();
					pstmt=con.prepareStatement(sql);*/
			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, employee.getBensyl_id().toUpperCase());
			pstmt.setString(2, employee.getEmp_email());
			rs=pstmt.executeQuery();
			if(rs.next()){
				status=rs.getString("status");
				if(status.equals("Active")){
					msg="exist";
				}
				else if(status.equals("notActive")){
					
					sql="update game_employee set password=?,status=? where bensyl_id=?";
					pstmt=dbCon.getStatement(sql);
					pstmt.setString(1, employee.getPassword());
					pstmt.setString(2, "Active");
					pstmt.setString(3, employee.getBensyl_id().toUpperCase());
					result=pstmt.executeUpdate();
					if(result==1){
						msg="activated";
					}
					else{						
					}
				}
			}
			else{
				msg="NotMatch";
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
					/*if(con!=null){
						con.close();
					}*/
			if(pstmt!=null){
				pstmt.close();
			}
			if(rs!=null){
				rs.close();
			}
		}
		return msg;
	}

	public List<OES> getOES() throws SQLException {
		
				//Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		DBConnection dbCon=new DBConnection();
		String sql="select oe_id,oe_name from game_oes";
		
		List<OES> oeList=new ArrayList<OES>();
		try {
					//con=dataSource.getConnection();
					//pstmt=con.prepareStatement(sql);
			pstmt=dbCon.getStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next()){
				OES objOE=new OES();
				objOE.setOe_Id(rs.getInt("oe_id"));
				objOE.setOe_Name(rs.getString("oe_name"));
				oeList.add(objOE);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
					//con.close();
			pstmt.close();
			rs.close();
		}		
		return oeList;
	}

	public List<Employee> getManagers() throws SQLException {
		
				//Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		DBConnection dbCon=new DBConnection();
		String sql="select m.bensyl_id,e.emp_name from game_manager m left join game_employee e on m.bensyl_id=e.bensyl_id";
		List<Employee> mngList=new ArrayList<Employee>();
		try {
					/*con=dataSource.getConnection();
					pstmt=con.prepareStatement(sql);*/
			pstmt=dbCon.getStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next()){
				Employee objEmp=new Employee();
				objEmp.setBensyl_id(rs.getString("bensyl_id"));
				objEmp.setEmp_name(rs.getString("emp_name"));
				mngList.add(objEmp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
					//con.close();
			pstmt.close();
			rs.close();
		}		
		return mngList;
	}


	@SuppressWarnings("resource")
	public String addManager1(Manager objManager) throws SQLException
	{
		String message="";
		String sql="";
		PreparedStatement pstmt=null;
				//Connection con=null;
		int result=0;
		ResultSet rs=null, rs2=null;
		DBConnection dbCon=new DBConnection();
		try {
					/*con=dataSource.getConnection();
					pstmt=con.prepareStatement(sql);*/
			sql="select emp_email from game_employee where upper(bensyl_id)=?";
			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, objManager.getBensyl_Id());
			rs=pstmt.executeQuery();
			if(rs.next()){
				sql="select * from game_manager where upper(bensyl_id)=?";
						//pstmt=con.prepareStatement(sql);
				pstmt=dbCon.getStatement(sql);
				pstmt.setString(1, objManager.getBensyl_Id());
				rs2=pstmt.executeQuery();
				if(rs2.next()){
					message="exist";						
				}
				else{
					sql="insert into game_manager values(?)";
							//pstmt=con.prepareStatement(sql);
					pstmt=dbCon.getStatement(sql);
					pstmt.setString(1, objManager.getBensyl_Id());
					result=pstmt.executeUpdate();
					if(result==1){
						message="added";
					}
					else{
						message="not added";
					}
				}					
			}
			else{
				message="error";					
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
					//con.close();
			pstmt.close();
			rs.close();
			if(rs2!=null){
				rs2.close();
			}
		}
		return message;
	}
	
	
	//method to query an employee's details
	public Employee getEmployee(String bensyl_id) throws SQLException {
		
		String sql="";
		PreparedStatement pstmt=null;
				//Connection con=null;
		ResultSet rs=null;
		DBConnection dbCon=new DBConnection();
		
		Employee objEmp=new Employee();
		sql="select bensyl_id,emp_name,emp_email,linemng_id from game_employee where upper(bensyl_id)=? and status <> 'deleted'";
		try {
			//get connection object from connection pool
					/*con=dataSource.getConnection();
					pstmt=con.prepareStatement(sql);*/
			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, bensyl_id);
			rs=pstmt.executeQuery();
			if(rs.next()){
				//set employee details to employee's object
				objEmp.setBensyl_id(rs.getString("bensyl_id"));
				objEmp.setEmp_name(rs.getString("emp_name"));
				objEmp.setLinemng_id(rs.getString("linemng_id"));
				objEmp.setEmp_email(rs.getString("emp_email"));
			}
			else{
				objEmp.setBensyl_id("null");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
					//con.close();
			pstmt.close();
			rs.close();
		}
		return objEmp;
	}

	@Override
	public int passwordCheck(Object obj) throws SQLException {
		
				//Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs1=null;
		String msg="",sql="";
		int result=0;
		DBConnection dbCon=new DBConnection();
		
		try {
					//con=dataSource.getConnection();
			if(obj instanceof Employee){
				Employee empObj=(Employee)obj;
				sql="select password from game_employee where bensyl_id=? and password=?";
						//pstmt=con.prepareStatement(sql);
				pstmt=dbCon.getStatement(sql);
				pstmt.setString(1, empObj.getBensyl_id());
				pstmt.setString(2, empObj.getPassword());
				rs1=pstmt.executeQuery();
				if(rs1.next()){
					result = 1;
				}
				else{
					result = -1;
				}
			}			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
					//con.close();
			pstmt.close();
			rs1.close();
		}
		return result;
	}

	@Override
	public String changePass(Object obj) throws SQLException {
		
				//Connection con=null;
		PreparedStatement pstmt=null;
		String msg="",sql="";
		int result=0;
		DBConnection dbCon=new DBConnection();
		
		try {
					//con=dataSource.getConnection();
			if(obj instanceof Employee){
				Employee empObj=(Employee)obj;
					sql="update game_employee set password=? where bensyl_id=?";
							//pstmt=con.prepareStatement(sql);
					pstmt=dbCon.getStatement(sql);
					pstmt.setString(1, empObj.getPassword());
					pstmt.setString(2, empObj.getBensyl_id());
					result=pstmt.executeUpdate();
					if(result==1){
						msg="changed";
					}
					else{
						msg="notChanged";
					}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
					//con.close();
			pstmt.close();
		}
		return msg;
	}
}
