/**
 * 
 */

function validateUserName(userName){
	var RegExp1=/^[a-zA-Z0-9]{6,7}$/;
	var RegExp2=/^[A-Za-z]+$/;
	var RegExp3=/^[0-9]+$/;
	var RegExp4=/[\s]*/;
	if(userName.match(RegExp3)){
		alert("Numbers only is not allowed in Username");
		return false;
	}
	else if(userName.match(RegExp2)){
		alert("Alphabets only is not allowed in username");
		return false;
	}
	else if(userName.match(RegExp1)){
		return true;
	}
	else if(userName.match(RegExp4)){
		alert("Spaces are not allowed in Staff or Bensyl ID");
		return false;
	}
}

function validateName(name){

	var RegExp=/^[a-zA-Z ]+$/;
	if(!(name.match(RegExp))){
		alert("Only letters and white space allowed");
		return false;
	}
	else{
		return true;
	}
}

function checkEmp(){
	
	if(document.empForm.manager.value=="select"){
		alert("Select a line manager");
		return false;
	}
	else if(document.empForm.oe_id.value=="select"){
		alert("Select an OE");
		return false;
	}
	else{
		return true;
	}
}

function validatePassAdmin(pass){
	
	var RegExp=/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
	if(!(pass.match(RegExp))){
		alert("Password : Atleast one UpperCase,one LowerCase, one Number, one special character and minimum 8 characters");
		return false;
	}
	else if(pass.match(RegExp)){
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("passMsg").innerHTML =
					this.responseText;
			}
		};
		xhttp.open("POST", "AdminController?pass="+pass+"&cmd=oldPA", true);
		xhttp.send();		
	}
	else{
		return true;
	}
	
}

function validatePass(pass){
	
	var RegExp=/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
	if(!(pass.match(RegExp))){
		alert("Password : Atleast one UpperCase,one LowerCase, one Number, one special character and minimum 8 characters");
		return false;
	}
	else{
		return true;
	}
	
}

function validatePassUser(pass){
	
	var RegExp=/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
	if(!(pass.match(RegExp))){
		alert("Password : Atleast one UpperCase,one LowerCase, one Number, one special character and minimum 8 characters");
		return false;
	}
	else if(pass.match(RegExp)){
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("passMsg").innerHTML =
					this.responseText;
			}
		};
		xhttp.open("POST", "EmployeeController?pass="+pass+"&cmd=oldPA", true);
		xhttp.send();		
	}
	else{
		return true;
	}
	
}

validatePassUser

function checkPass(){
	var newpass1=document.changePass.newpass1.value;
	var newpass2=document.changePass.newpass2.value;
	if(newpass1!=newpass2){
		alert("Password Mismatch");
		document.changePass.newpass1.value="";
		document.changePass.newpass2.value="";
		return false;
	}
	else{
		return true;
	}
}



