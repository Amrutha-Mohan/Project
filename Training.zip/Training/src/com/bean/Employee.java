package com.bean;

public class Employee {

	private String emp_id;
	private String emp_fname;
	private String emp_lname;
	private String emp_email;
	private String  linemng_id;
	private String password;
	
	public Employee() {
		super();
	}
	
	public Employee(String emp_id, String emp_fname, String emp_lname, String emp_email, String linemng_id,
			String password) {
		super();
		this.emp_id = emp_id;
		this.emp_fname = emp_fname;
		this.emp_lname = emp_lname;
		this.emp_email = emp_email;
		this.linemng_id = linemng_id;
		this.password = password;
	}
	
	public Employee(String emp_id, String emp_fname, String emp_lname, String emp_email, String linemng_id) {
		super();
		this.emp_id = emp_id;
		this.emp_fname = emp_fname;
		this.emp_lname = emp_lname;
		this.emp_email = emp_email;
		this.linemng_id = linemng_id;
	}
	
	public String getEmp_id() {
		return emp_id;
	}
	
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	
	public String getEmp_fname() {
		return emp_fname;
	}
	
	public void setEmp_fname(String emp_fname) {
		this.emp_fname = emp_fname;
	}
	
	public String getEmp_lname() {
		return emp_lname;
	}
	
	public void setEmp_lname(String emp_lname) {
		this.emp_lname = emp_lname;
	}
	
	public String getEmp_email() {
		return emp_email;
	}
	
	public void setEmp_email(String emp_email) {
		this.emp_email = emp_email;
	}
	
	public String getLinemng_id() {
		return linemng_id;
	}
	
	public void setLinemng_id(String linemng_id) {
		this.linemng_id = linemng_id;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}

}

