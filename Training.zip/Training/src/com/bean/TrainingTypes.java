package com.bean;

public class TrainingTypes {
	
	private int tn_id;
	private String tn_type;
	private float tn_weightage;
	
	public TrainingTypes() {
		super();
	}
	
	public TrainingTypes(int tn_id, String tn_type, float tn_weightage) {
		super();
		this.tn_id = tn_id;
		this.tn_type = tn_type;
		this.tn_weightage = tn_weightage;
	}
	
	public int getTn_id() {
		return tn_id;
	}
	
	public void setTn_id(int tn_id) {
		this.tn_id = tn_id;
	}
	
	public String getTn_type() {
		return tn_type;
	}
	
	public void setTn_type(String tn_type) {
		this.tn_type = tn_type;
	}
	
	public float getTn_weightage() {
		return tn_weightage;
	}
	
	public void setTn_weightage(float tn_weightage) {
		this.tn_weightage = tn_weightage;
	}
	
}
