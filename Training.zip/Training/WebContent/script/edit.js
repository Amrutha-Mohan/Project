/**
 * 
 */

/*function loadEditForm() {
	var xhttp = new XMLHttpRequest();
	var id=document.getElementById("empid").value;
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById("edit").innerHTML =
				this.responseText;
		}
	};
	xhttp.open("GET", "employee_edit.jsp?val="+id, true);
	xhttp.send(); 
}*/

function loadEditForm1() {
	var xhttp = new XMLHttpRequest();
	var id=document.getElementById("empid").value;
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById("edit").innerHTML =
				this.responseText;
		}
	};
	xhttp.open("GET", "EmployeeController?val="+id+"&cmd=searchEmp", true);
	xhttp.send(); 
}

function loadTrainings() {
	var xhttp = new XMLHttpRequest();
	var mngId=document.getElementById("mngr").value;
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById("training").innerHTML =
				this.responseText;
		}
	};
	xhttp.open("POST", "ReportController?id="+mngId+"&cmd=loadTrn", true);
	xhttp.send(); 
}
